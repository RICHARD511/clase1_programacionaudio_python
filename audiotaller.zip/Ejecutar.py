from onda import ondas
from cuadra import cuadrada
from triang import triangular
from diente import sierra
from Archivar import file
from nivelesdeaudio import fileopen

def main():

    print ("Senales")
    
    opcion = input("Escoja una opcion: \n 1.Sinosoidal \n 2.Cuadrada \n 3.Triangular \n 4.Diente de Sierra \n ")
    print ("Ingrese los datos: \n ")
    Tone = input("Digite la frecuencia del tono:  ")
    Time = input("Ingrese el tiempo de audio en segundos: ")
    Frecuenciademuestreo = input("Ingrese la frecuencia de muestreo: ")
    Pbits = input("Ingrese el numero de bits: ")
    VpdBFS=input("Ingrese el nivel pico en dB: ")
    Name = raw_input("Ingrese el nombre del archivo: ")
    Name = (Name+".wav")

    if opcion == 1:

        senal = ondas(Tone, Frecuenciademuestreo, Pbits, Time, VpdBFS)
        onda = senal.sinusoidal()

        doc = file(Frecuenciademuestreo, Pbits, Name)
        doc.archive(onda)

        senal.graficar(onda)

    if opcion == 2:

        senal = cuadrada(Tone, Frecuenciademuestreo, Pbits, Time, VpdBFS)
        onda = senal.square()

        doc = file(Frecuenciademuestreo, Pbits, Name)
        doc.archive(onda)

        senal.graficar(onda)

    if opcion == 3:

        senal = triangular(Tone, Frecuenciademuestreo, Pbits, Time, VpdBFS)
        onda = senal.triangulo()

        doc = file(Frecuenciademuestreo, Pbits, Name)
        doc.archive(onda)

        senal.graficar(onda)

    if opcion == 4:

        senal = sierra(Tone, Frecuenciademuestreo, Pbits, Time, VpdBFS)
        onda = senal.diente()

        doc = file(Frecuenciademuestreo, Pbits, Name)
        doc.archive(onda)

        senal.graficar(onda)





if __name__== "__main__":
    main()