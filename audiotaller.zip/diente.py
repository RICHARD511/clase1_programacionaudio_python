import math
import matplotlib.pylab as plt

class sierra:

    wavearray = []

    def __init__(self, frecuencia, fmuestreo, pbits, time, vpico):
        self.Frecuenciam = fmuestreo
        self.Profundidadb = pbits
        self.Duracion = time
        self.Frecuencia = frecuencia
        self.vpdBFS = vpico
        self.size = fmuestreo * time
    def diente(self):

        for i in range(0, self.size):
            a=((0.5)-(1/math.pi)*(10**(self.vpdBFS/20)*(20*math.log10(2**self.Profundidadb))))
            datos=0
            for j in range(1, 100):
                value=math.sin((j*math.pi*self.Frecuencia*i)/self.Frecuenciam)
                datos=datos+value
            frame=datos*a
            sierra.wavearray.append(frame)

        return sierra.wavearray



    def graficar(self, array):
        plt.plot(array, color="purple", linewidth=1.0, linestyle="-")
        plt.show()