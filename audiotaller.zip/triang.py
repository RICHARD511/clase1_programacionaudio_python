import math
import matplotlib.pylab as plt

class triangular:

    wavearray = []

    def __init__(self, frecuencia, fmuestreo, pbits, time, vpico):
        self.Frecuenciam = fmuestreo
        self.Profundidadb = pbits
        self.Duracion = time
        self.Frecuencia = frecuencia
        self.vpdBFS = vpico
        self.size = fmuestreo * time

    def triangulo(self):

        for i in range(0, self.size):
            a=((8/math.pi**2)*(10**(self.vpdBFS/20)*(20*math.log10(2**self.Profundidadb))))
            datos=0

            for j in range(1, 100):
                par=j%2
                if par:
                    val=(-1**((j-1)/2))/j**2
                    value=val*math.sin((j*math.pi*self.Frecuencia*i)/self.Frecuenciam)
                    datos=datos+value
            forma=datos*a

            triangular.wavearray.append(forma)

        return triangular.wavearray



    def graficar(self, array):
        plt.plot(array, color="yellow", linewidth=1.0, linestyle="-")
        plt.show()