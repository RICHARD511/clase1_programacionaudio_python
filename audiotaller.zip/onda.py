import math
import matplotlib.pylab as plt

class ondas:
    wavearray = []

    def __init__(self, frecuencia, fmuestreo, pbits, time, vpico):
        self.Frecuenciam = fmuestreo
        self.Profundidadb = pbits
        self.Duracion = time
        self.Frecuencia = frecuencia
        self.vpdBFS = vpico
        self.size = fmuestreo * time

    def sinusoidal(self):

        for i in range(0, self.size):

            valores = (10**(self.vpdBFS/20)*(20*math.log10(2**self.Profundidadb)))*math.sin((2*math.pi*self.Frecuencia*i)/self.Frecuenciam)
            ondas.wavearray.append(valores)

        return ondas.wavearray

    def graficar(self, array):
        plt.plot(array, color="green", linewidth=1.0, linestyle="-")
        plt.show()
