import math
import matplotlib.pylab as plt

class cuadrada:

    wavearray = []

    def __init__(self, frecuencia, fmuestreo, pbits, time, vpico):
        self.Frecuenciam = fmuestreo
        self.Profundidadb = pbits
        self.Duracion = time
        self.Frecuencia = frecuencia
        self.vpdBFS = vpico
        self.size = fmuestreo * time
    def square(self):


        for i in range(0, self.size):
            a=((4/math.pi)*(10**(self.vpdBFS/20)*(20*math.log10(2**self.Profundidadb))))
            datos=0
            for j in range(0, 100):
                par=j%2
                if par:


                    valores=math.sin(((j*math.pi*self.Frecuencia*i))/self.Frecuenciam)
                    datos=datos + valores

            forma=datos*a

            cuadrada.wavearray.append(forma)

        return cuadrada.wavearray



    def graficar(self, array):
        plt.plot(array, color="red", linewidth=1.0, linestyle="-")
        plt.show()